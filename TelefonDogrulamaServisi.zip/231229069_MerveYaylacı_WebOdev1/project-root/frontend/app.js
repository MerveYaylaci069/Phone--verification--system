const API_BASE = 'http://localhost:3000'; 

document.getElementById('regForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();

  const resultDiv = document.getElementById('result');
  resultDiv.textContent = 'Gönderiliyor...';

  try {
    const res = await fetch(`${API_BASE}/api/registration`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({ name, email, phone })
    });
    const data = await res.json();
    if (res.status === 201) {
      resultDiv.style.color = 'green';
      resultDiv.textContent = data.message || 'Kayıt başarılı';
      
      addRow(data.data);
    } else {
      resultDiv.style.color = 'red';
      resultDiv.textContent = data.message || JSON.stringify(data);
    }
  } catch (err) {
    resultDiv.style.color = 'red';
    resultDiv.textContent = 'Sunucuya ulaşılamıyor';
  }
});

function addRow(row) {
  if (!row) return;
  const tbody = document.querySelector('#recent tbody');
  const tr = document.createElement('tr');
  tr.innerHTML = `<td>${row.id}</td><td>${row.name}</td><td>${row.email}</td><td>${row.phone}</td><td>${row.created_at || ''}</td>`;
  tbody.prepend(tr);
}
