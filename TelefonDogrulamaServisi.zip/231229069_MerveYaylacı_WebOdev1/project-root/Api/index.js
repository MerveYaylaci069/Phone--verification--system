const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const pool = require('./db');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const PORT = process.env.PORT || 3000;


function validatePhoneNumberString(number) {
  
  if (typeof number !== 'string') return { error: 'number must be a string' };
  if (!/^\d{6}$/.test(number)) return { error: 'number must be 6 digits' };

  const digits = number.split('').map(d => parseInt(d, 10));
  const [a1,a2,a3,a4,a5,a6] = digits;

  const hasNonZeroDigit = digits.some(d => d !== 0);
  const sumFirstEqualsLast = (a1 + a2 + a3) === (a4 + a5 + a6);
  const sumOddEqualsEven = (a1 + a3 + a5) === (a2 + a4 + a6);

  const isValid = hasNonZeroDigit && sumFirstEqualsLast && sumOddEqualsEven;

  return {
    number,
    rules: {
      hasNonZeroDigit,
      sumFirstEqualsLast,
      sumOddEqualsEven
    },
    isValid
  };
}


app.post('/api/phone/validate', (req, res) => {
  const { number } = req.body;
  if (!number) return res.status(400).json({ error: 'number is required' });

  const result = validatePhoneNumberString(String(number));
  if (result.error) return res.status(400).json({ error: result.error });

  return res.json(result);
});


app.post('/api/registration', async (req, res) => {
  try {
    const { name, email, phone } = req.body;
    if (!name || !email || !phone) return res.status(400).json({ status: 'error', message: 'name, email and phone required' });

    const phoneStr = String(phone);
    const validation = validatePhoneNumberString(phoneStr);
    if (validation.error) return res.status(400).json({ status: 'error', message: validation.error });

    if (!validation.isValid) {
      return res.status(422).json({
        status: 'denied',
        message: 'Geçersiz telefon numarası. Lütfen yeni bir numara deneyin.',
        isValid: false
      });
    }

    
    const conn = await pool.getConnection();
    try {
      const [result] = await conn.query(
        'INSERT INTO registrations (name, email, phone) VALUES (?, ?, ?)',
        [name, email, phoneStr]
      );
      const insertedId = result.insertId;
      const [rows] = await conn.query('SELECT id, name, email, phone, created_at FROM registrations WHERE id = ?', [insertedId]);
      return res.status(201).json({
        status: 'accepted',
        message: 'Telefon numarası geçerli, kayıt başarıyla oluşturuldu.',
        data: rows[0]
      });
    } catch (err) {
      
      if (err.code === 'ER_DUP_ENTRY') {
        return res.status(409).json({ status: 'error', message: 'Bu telefon numarası zaten kayıtlı.' });
      }
      console.error(err);
      return res.status(500).json({ status: 'error', message: 'Sunucu hatası' });
    } finally {
      conn.release();
    }
  } catch (err) {
    console.error(err);
    return res.status(500).json({ status: 'error', message: 'Sunucu hatası' });
  }
});


app.get('/api/phone/count', async (req, res) => {
  
  return res.json({ count: 6699 });
});

app.listen(PORT, () => {
  console.log(`API listening on port ${PORT}`);
});
